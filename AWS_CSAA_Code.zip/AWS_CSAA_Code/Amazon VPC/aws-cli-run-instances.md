# Launch instance in Public 1A
aws ec2 run-instances --image-id <value> --instance-type <value> --security-group-ids <value> --subnet-id <value> --key-name <value> --user-data <value>


# Launch instance in Public 1B


# Launch instance in Private 1B


# Terminate instances

aws ec2 terminate-instances --instance-ids <value> <value>